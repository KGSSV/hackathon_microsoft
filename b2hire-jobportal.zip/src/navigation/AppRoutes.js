import React from 'react';
import { Route, Routes } from "react-router-dom";
import Jobs from '../pages/Jobs';
import JobDetails from '../pages/JobDetails';

export default function AppRoutes() {
  return (
    <Routes>
      
      <Route path="/" element={<Jobs/>}/>
      <Route path="/apply/:jobid" element={<JobDetails/>}/>
      
    </Routes>
  )
}
