import React, { useState } from "react";
import { BlobServiceClient, AnonymousCredential } from "@azure/storage-blob";

const UploadFile = () => {
    const [file, setFile] = useState(null);
    const [containerName, setContainerName] = useState("resume");
    const [accountName, setAccountName] = useState("b2hireai");
    const [sasToken, setSasToken] = useState("sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-06-30T19:22:03Z&st=2024-05-17T11:22:03Z&spr=https&sig=%2FWSwzvAyGS%2B5HskuNeyo%2BUGxglS7cLlWS10p5Hx%2B3fo%3D");

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleUpload = async () => {
        if (!file) {
            alert("Please select a file.");
            return;
        }

        const blobServiceClient = new BlobServiceClient(
            `https://${accountName}.blob.core.windows.net/?${sasToken}`,
            new AnonymousCredential()
        );

        const containerClient = blobServiceClient.getContainerClient(containerName);
        const blobClient = containerClient.getBlockBlobClient(file.name);

        try {
            await blobClient.uploadData(file, {
                blobHTTPHeaders: {
                    blobContentType: file.type,
                },
            });
            alert("File uploaded successfully.");
        } catch (error) {
            console.error("Error uploading file:", error);
            alert("Failed to upload file.");
        }
    };

    return (
        <div>
            <h2>Upload File</h2>
            <input type="file" onChange={handleFileChange} />
            <button onClick={handleUpload}>Upload</button>
        </div>
    );
};

export default UploadFile;
