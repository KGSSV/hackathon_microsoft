import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Chip from "@mui/material/Chip";
import Button from "@mui/material/Button";
import Avatar from "@mui/material/Avatar";
import { styled } from "@mui/material/styles";
import IconButton from "@mui/material/IconButton";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import { useNavigate } from "react-router-dom";
import brillioLogo from '../assests/logo.png'

export default function JobCard({ job, color }) {


  const JobCard = styled(Card)(({ theme }) => ({
    borderRadius: "16px",
    maxWidth: 445,
    position: "relative",
    minHeight: 400,
    border: "1px solid #c3c3c3", // Add thick black borders
    overflow: "hidden",
  }));

  const ColoredLayer = styled(Box)(({ theme }) => ({
    backgroundColor: color,
    padding: theme.spacing(2),
    position: "relative",
    margin: theme.spacing(1),
    borderRadius: "10px",
    minHeight: 300,
  }));

  const JobTitle = styled(Typography)(({ theme }) => ({
    fontWeight: "bold",
    fontSize: "1.2rem",
    marginBottom: theme.spacing(1),
    fontFamily: "Open Sans, sans-serif",
  }));

  const CompanyLogo = styled(Avatar)(({ theme }) => ({
    width: 50,
    height: 50,
    position: "absolute",
    top: theme.spacing(2),
    right: theme.spacing(2),
  }));

  const DateBox = styled(Box)(({ theme }) => ({
    position: "absolute",
    top: theme.spacing(2),
    left: theme.spacing(2),
    backgroundColor: "#fff",
    padding: theme.spacing(0.5, 1),
    borderRadius: theme.shape.borderRadius,
  }));

  const PriceBox = styled(Box)(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: theme.spacing(2),
  }));

  const LocationText = styled(Typography)(({ theme }) => ({
    color: theme.palette.text.secondary,
  }));

  const SkillsBox = styled(Box)(({ theme }) => ({
    display: "flex",
    gap: theme.spacing(1),
    flexWrap: "wrap",
    marginTop: theme.spacing(1),
    fontFamily: "Montserrat, sans-serif",
    justifyContent: "center",
  }));

  const DetailButtonBox = styled(Box)(({ theme }) => ({
    display: "flex",
    justifyContent: "center",
    padding: theme.spacing(2),
  }));

  const DetailButton = styled(Button)(({ theme }) => ({
    backgroundColor: "#000",
    color: "#fff",
    borderRadius: theme.shape.borderRadius,
    "&:hover": {
      backgroundColor: "#333",
    },
  }));

  const navigate = useNavigate();

  const handleJobDetails = (jobID) => {
    navigate(`/apply/${jobID}`);
  };
  return (
    <JobCard>
      <DateBox>
        <Typography variant="caption">20 May, 2023</Typography>
      </DateBox>
      <IconButton style={{ position: "absolute", top: 8, right: 60 }}>
        <BookmarkBorderIcon />
      </IconButton>
      <ColoredLayer>
        <CompanyLogo src={brillioLogo} alt="Company Logo" />
        <CardContent>
          <Typography
            style={{ fontFamily: "Montserrat, sans-serif" }}
            variant="subtitle2"
          >
            {job?.jobID}
          </Typography>
          <JobTitle>{job?.PositionName}</JobTitle>
          <SkillsBox>
            {job?.skillsRequired.slice(0, 4).map((item, index) => (
              <Chip
                key={index}
                label={item}
                style={{
                  fontFamily: "Montserrat, sans-serif",
                  border: "1px solid #604f4f",
                }}
              />
            ))}
          </SkillsBox>
          <PriceBox>
            <Typography variant="body">YOE - {job?.yoe}</Typography>
            <LocationText>San Francisco, CA</LocationText>
          </PriceBox>
        </CardContent>
      </ColoredLayer>
      <DetailButtonBox>
        <DetailButton variant="contained" onClick={() => handleJobDetails(job?.jobID)}
>
          Details
        </DetailButton>
      </DetailButtonBox>
    </JobCard>
  );
}
