import React from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import Loader from "../components/Loader";
import {
  Container,
  Typography,
  Grid,
  Button,
  Card,
  CardContent,
  CardMedia,
} from "@mui/material";
import logo from "../assests/logo.png";

export default function JobDetail({ job }) {
  console.log(job.skillsRequired);

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        {job?.PositionName}
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Grid container alignItems="center" spacing={2}>
                <Grid item>
                  <CardMedia
                    component="img"
                    src={logo}
                    alt="Company Logo"
                    sx={{ width: 50, height: 50, borderRadius: "50%" }}
                  />
                </Grid>
                <Grid item>
                  <Typography variant="subtitle1" color="#1615be">
                    Brillio
                  </Typography>
                  <Typography variant="subtitle2" color="#525257">
                    Year Of Experience - {job?.yoe}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Job Description
              </Typography>
              <Typography variant="body1" paragraph>
                {job?.jobDescContent}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Skills
              </Typography>
              <Typography variant="body1" paragraph>
                <ul>
                  {job?.skillsRequired.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}
