import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  RadioGroup,
  Radio,
  FormControlLabel,
  Typography,
} from '@mui/material';
import { useSelector } from 'react-redux';
import Loader from './Loader';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';


export default function QuizDialog({ open, onClose }) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(-1);
  const [selectedOption, setSelectedOption] = useState('');
  const [responses, setResponses] = useState([]);
  const [timer, setTimer] = useState(30);
  const { screeningQuestions, screeningQuestionsLoading } = useSelector((state) => state.apply);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  useEffect(() => {
    let interval;
    if (open && currentQuestionIndex >= 0 && currentQuestionIndex < screeningQuestions?.length) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer <= 1) {
            handleSave(selectedOption);
            return 30;
          }
          return prevTimer - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [open, currentQuestionIndex, selectedOption]);

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleSave = (option) => {
    if (currentQuestionIndex >= 0 && currentQuestionIndex < screeningQuestions?.length) {
      const newResponses = [
        ...responses,
        {
          question: screeningQuestions[currentQuestionIndex].question,
          response: option || selectedOption,
          correct_answer: screeningQuestions[currentQuestionIndex].correct_answer,
        },
      ];
      setResponses(newResponses);
    }

    setSelectedOption('');
    setTimer(30);

    if (currentQuestionIndex < screeningQuestions?.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1); // To move to the "Thanks" view
    }
  };

  const handleStart = () => {
    setCurrentQuestionIndex(0);
  };

  const isQuizEnd = currentQuestionIndex === screeningQuestions?.length;

  const calculateCorrectAnswers = (responses) => {
    console.log("Response", responses)
    return responses.filter((response) => response.response === response.correct_answer).length;
  };

  return (
    <Dialog open={open}  onClose={() => onClose(responses, calculateCorrectAnswers(responses))}>
      <DialogTitle>Quiz</DialogTitle>
      <DialogContent sx={{ width: 450, minWidth: 450, height:300, minHeight: 300 }}>
  {currentQuestionIndex === -1 ? (
    <div>
      <Typography variant="h6">Guidelines</Typography>
      <Typography>
        1. You will have 30 seconds to answer each question.
        <br />
        2. Once the time is up, the answer will be saved automatically.
        <br />
        3. You can save your answer by clicking the "Save" button.
        <br />
        4. At the end, you will see a "Thanks for attempting the quiz" message.
        <br />
      </Typography>
      <Button onClick={handleStart} variant="contained" color="primary" style={{ marginTop: '20px' }}>
        Start Test
      </Button>
    </div>
  ) : isQuizEnd ? (
    <Typography variant="h6">Thanks for attempting the quiz!</Typography>
  ) : (
    screeningQuestionsLoading ? (
      <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div style={{ marginBottom: '10px' }}>Setting Up Quiz</div>
      <Loader />
    </div>
    ) : (
      screeningQuestions && (
        <div>
          <Typography>{screeningQuestions[currentQuestionIndex].question}</Typography>
          <RadioGroup value={selectedOption} onChange={handleOptionChange}>
            {screeningQuestions[currentQuestionIndex].options.map((option, index) => (
              <FormControlLabel key={index} value={option} control={<Radio />} label={option} />
            ))}
          </RadioGroup>
          <Typography variant="caption">Time left: {timer} seconds</Typography>
        </div>
      )
    )
  )}
</DialogContent>


      <DialogActions>
        {currentQuestionIndex !== -1 && !isQuizEnd && (
          <Button onClick={() => handleSave(selectedOption)} disabled={!selectedOption}>
            Save
          </Button>
        )}
        {isQuizEnd && (
          <Button onClick={() => onClose(responses, calculateCorrectAnswers(responses))} variant="contained" color="primary">
            Close
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
