import React, { useState } from 'react';
import {
  TextField,
  Button,
  Container,
  Box,
  Typography,
  Grid
} from '@mui/material';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { apply, uploadResume } from '../redux/thunk/Jobs.thunk';
import { setApplicationInfo } from '../redux/slice/Apply.slice';



const validationSchema = yup.object({
  name: yup
    .string('Enter your name')
    .required('Name is required'),
  email: yup
    .string('Enter your email')
    .email('Enter a valid email')
    .required('Email is required'),
  experience: yup
    .number('Enter your years of experience')
    .required('Years of experience is required')
    .min(0, 'Experience cannot be negative')
});

export default function Apply({jobid, openQuizDialog})  {
  const [resume, setResume] = useState(null);
  const [email, setemail] = useState('');
  const [formValues, setformValues] = useState(null);
  const { uploadResp, loadingUploadResp } = useSelector((state) => state.apply);
  const dispatch = useDispatch();

  const handleApplyClick = () => {
    // Other apply logic can go here
    openQuizDialog();
  };
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      experience: ''
    },

    
    validationSchema: validationSchema,
    onSubmit: (values) => {
      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('email', values.email);
      formData.append('experience', values.experience);
      
      const params = {
        filename: resume.name,
        yoe: values.experience,
        name: values.name,
        email: values.email,
        status: "Initial Round",
        blobpath: `${values.email}/${jobid}/${resume.name}`,
        jid: jobid
      }
      // Handle form submission
      dispatch(apply(params));
      dispatch(setApplicationInfo(params))
      handleApplyClick();
      console.log('Form Data:', values);
      // Submit the form data
    }
  });


  const handleChange = (event) => {
    formik.handleChange(event);
    if (event.target.name === 'email') {
      setemail( event.target.value);
    }
  };
 

  const handleResumeUpload = (event) => {
    setResume(event.target.files[0]);
    const path = `${email}/${jobid}`
    console.log("EMAIL", path)
    const file = event.target.files[0];
    dispatch(uploadResume({file, path}));
    
  };

  return (
    <Container>
    
        <Typography component="h1" variant="h5">
          Apply Here!
        </Typography>
        <form onSubmit={formik.handleSubmit}>
          <Grid container spacing={2} sx={{marginTop: '10px'}}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="name"
                name="name"
                label="Name"
                value={formik.values.name}
                onChange={formik.handleChange}
                error={formik.touched.name && Boolean(formik.errors.name)}
                helperText={formik.touched.name && formik.errors.name}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="email"
                name="email"
                label="Email"
                value={formik.values.email}
                onChange={handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="experience"
                name="experience"
                label="Year Of Experience"
                value={formik.values.experience}
                onChange={formik.handleChange}
                error={formik.touched.experience && Boolean(formik.errors.experience)}
                helperText={formik.touched.experience && formik.errors.experience}
              />
            </Grid>
            <Grid item xs={12}>
              <Button
                variant="contained"
                component="label"
              >
                Upload Resume
                <input
                  type="file"
                  hidden
                  accept=".pdf,.doc,.docx"
                  onChange={handleResumeUpload}
                />
              </Button>
              {resume && <Typography variant="body2" mt={1}>{resume.name}</Typography>}
            </Grid>
            <Grid item xs={12}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                disabled={!formik.isValid || !uploadResp}
              >
                Apply
              </Button>
            </Grid>
          </Grid>
        </form>
    </Container>
  );
};

