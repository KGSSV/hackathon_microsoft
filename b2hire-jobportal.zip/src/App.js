
import { useDispatch } from 'react-redux';
import './App.css';
import NavBar from './components/NavBar';
import { BrowserRouter as Router } from "react-router-dom";
import { useEffect } from 'react';
import { apply, getJobListings } from './redux/thunk/Jobs.thunk';
function App() {

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getJobListings());
  }, [dispatch]);
  return (
    <Router>
    <NavBar/>
    </Router>
  );
}

export default App;
