export const NAV_BAR_ITEMS = [
    {
        title: "Home",
        image: "",
        link: "/"
    },
    
    
]



export const CARDS_COLOR = [
    "#f7ccff", "#ffe0cc", "#ccffd9", "#ceccff", "#ffd0cc", "#fffabb"
]