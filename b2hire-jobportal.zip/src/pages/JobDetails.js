import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import Loader from '../components/Loader';
import JobDetail from '../components/JobDetail';
import Apply from '../components/Apply';
import { Container, Grid, Divider, Button } from '@mui/material';
import QuizDialog from '../components/QuizDialog';
import { clearScreeningQuestions } from '../redux/slice/Apply.slice';
import { submitQuiz } from '../redux/thunk/Jobs.thunk';

export default function JobDetails() {
  const { jobid } = useParams(); // Get the jobid from the URL parameters
  const { jobsList, jobsListLoading } = useSelector((state) => state.jobs);
  const { screeningQuestions, screeningQuestionsLoading, applicationInfo } = useSelector((state) => state.apply);

  // Find the job from the jobsList using jobid
  const job = jobsList?.find(job => job.jobID === jobid);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [quizResponses, setQuizResponses] = useState([]);
  const [correctAnswersCount, setCorrectAnswersCount] = useState(0);
  const dispatch = useDispatch();


  const handleDialogClose = (responses, correctAnswers) => {
    setDialogOpen(false);
    setQuizResponses(responses);
    setCorrectAnswersCount(correctAnswers);
    const params = {
      status: correctAnswers > 3 ? 'INITIAL OK' : 'REJECTED',
      email: applicationInfo?.email,
      name: applicationInfo?.name,
      positionname: job.PositionName,
      jid: applicationInfo.jid,
      
    }

    dispatch(submitQuiz(params));
  };

  const openQuizDialog = () => {
    setDialogOpen(true);
  };

  return (
    <Container>
      {jobsListLoading && <Loader />}
      {!jobsListLoading && jobsList && job && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={7}>
            <JobDetail job={job} />
          </Grid>
          <Grid item xs={12} md={1}>
            <Divider orientation="vertical" flexItem sx={{ borderRightWidth: 1, borderColor: 'black' }} />
          </Grid>
          <Grid item xs={12} md={4}>
            <Apply jobid={jobid} openQuizDialog={openQuizDialog} />
          </Grid>
        </Grid>
      )}

      <QuizDialog open={dialogOpen} onClose={handleDialogClose} />
    </Container>
  );
}
