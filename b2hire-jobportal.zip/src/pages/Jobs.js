import React, { useEffect, useState } from 'react';
import JobCard from '../components/JobCard';
import { useDispatch, useSelector } from 'react-redux';
import { getJobListings } from '../redux/thunk/Jobs.thunk';
import { Grid } from '@material-ui/core';
import Loader from '../components/Loader';
import { CARDS_COLOR } from '../constants/constant';

export default function Jobs() {
  const { jobsList, jobsListLoading } = useSelector((state) => state.jobs);

  const getRandomColor = (jobId, rowIndex, usedColors) => {
    const availableColors = CARDS_COLOR.filter(color => !usedColors.includes(color));
    const color = availableColors[Math.floor(Math.random() * availableColors.length)];
    usedColors[rowIndex].push(color);
    return color;
  };

  let gridCount = 3;
  if(jobsList?.length===3) gridCount = 4;
  if(jobsList?.length<3) gridCount = 6;



  return (
    <>
      {jobsListLoading && <Loader />}
      {!jobsListLoading && jobsList &&
        <Grid container spacing={2} justifyContent={jobsList.length < 4 ? 'center' : 'flex-start'}>
          {jobsList.map((job, index) => {
            const rowIndex = Math.floor(index / 4); // Assuming 4 cards per row
            const usedColors = Array.from({ length: Math.ceil(jobsList.length / 4) }, () => []);
            return (
              <Grid item xs={12} sm={6} md={gridCount} key={index}>
                <JobCard job={job} color={getRandomColor(job?.jobID, rowIndex, usedColors)} />
              </Grid>
            );
          })}
        </Grid>
      }
    </>

  
    
  );
}
