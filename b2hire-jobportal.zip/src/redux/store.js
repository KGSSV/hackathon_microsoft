import { configureStore } from "@reduxjs/toolkit";
import JobsReducer from './slice/Jobs.slice'
import ApplyReducer from "./slice/Apply.slice";

const store = configureStore({
  reducer: {
    jobs: JobsReducer,
    apply: ApplyReducer
  },
});

export default store;
  