import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import UploadService from "./service/UploadService";

export const getJobListings = createAsyncThunk(
  "jobs/jobslisting",
  async (userDetails,{ rejectWithValue }) => {
    console.log("THUNK")
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/jobslisting`
      );

      return data;
    } catch (error) {
      return rejectWithValue("Unable to fetch data");
    }
  }
);

export const apply = createAsyncThunk(
  "jobs/apply",
  async (applicationInfo, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/apply`,
        {
          filename: applicationInfo?.filename ,
          YOE: applicationInfo?.yoe,
          name: applicationInfo?.name,
          email: applicationInfo?.email,
          cstatus: applicationInfo?.status,
          resumeblobpath: applicationInfo?.blobpath,
          jid: applicationInfo?.jid,
        }
      );
      return data;
    } catch (error) {
      return rejectWithValue("Something Went Wrong");
    }
  }
);

export const uploadResume = createAsyncThunk(
  "jobs/uploadResume",
  async ({file, path}, { rejectWithValue }) => {
    try {
      console.log("UPLOAD THUNK", file, path)
      const  data  = await UploadService(file,path);
      console.log("RESP", data)
      return data;
    } catch (error) {
      return rejectWithValue("Something Went Wrong");
    }
  }
);


export const submitQuiz = createAsyncThunk(
  "jobs/submitQuiz",
  async (params, { rejectWithValue }) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/submitInit`,
        {
          cstatus: params.status,
          emailid: params.email,
          name: params.name,
          positionname: params.positionname,
          jid: params.jid
        }
      );
      return data;
    } catch (error) {
      return rejectWithValue("Something Went Wrong");
    }
  }
);





