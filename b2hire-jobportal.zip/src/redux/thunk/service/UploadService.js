import { BlobServiceClient, AnonymousCredential } from "@azure/storage-blob";

export default async function UploadService(file, path) {
    const containerName = "resume";
    const accountName = "b2hireai";
    const sasToken = "sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-06-30T19:22:03Z&st=2024-05-17T11:22:03Z&spr=https&sig=%2FWSwzvAyGS%2B5HskuNeyo%2BUGxglS7cLlWS10p5Hx%2B3fo%3D";

    const blobServiceClient = new BlobServiceClient(
        `https://${accountName}.blob.core.windows.net/?${sasToken}`,
        new AnonymousCredential()
    );

    const containerClient = blobServiceClient.getContainerClient(containerName);
    const blobClient = containerClient.getBlockBlobClient(`${path}/${file.name}`);

    try {
        await blobClient.uploadData(file, {
            blobHTTPHeaders: {
                blobContentType: file.type,
            },
        });
        return "File uploaded successfully.";
    } catch (error) {
        console.error("Error uploading file:", error);
        return "Failed to upload file.";
    }

}
