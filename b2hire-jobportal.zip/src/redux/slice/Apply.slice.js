
import { createSlice } from "@reduxjs/toolkit";
import { apply, uploadResume } from "../thunk/Jobs.thunk";

const initialState = {
    applicationInfo: null,
    screeningQuestions: false,
    screeningQuestionsError: false,
    screeningQuestionsLoading: false,
    uploadResp: null,
    loadingUploadResp: false
};

const applySlice = createSlice({
    name: "Apply_SLICE",
    initialState,
    reducers:{
        setApplicationInfo (state, action){
            state.applicationInfo = action.payload;
        },
        clearScreeningQuestions(state){
            state.screeningQuestions = null;
        }
    },
    extraReducers: (builder) => {
        builder.addCase(apply.fulfilled,(state, action)=>{
            state.screeningQuestions = action.payload;
            state.screeningQuestionsLoading = false;
        })
        .addCase(apply.pending,(state)=>{
            state.screeningQuestionsLoading = true;
        })
        .addCase(apply.rejected, (state, action)=>{
            state.screeningQuestionsError = action.payload;
            state.screeningQuestionsLoading = false;
        })
        .addCase(uploadResume.fulfilled, (state, action)=>{
            state.uploadResp = action.payload;
            state.loadingUploadResp = false;
        })
        .addCase(uploadResume.pending,(state)=>{
            state.loadingUploadResp = true;
        });
    }
})

export const { clearScreeningQuestions, setApplicationInfo } = applySlice.actions;
export default applySlice.reducer;
