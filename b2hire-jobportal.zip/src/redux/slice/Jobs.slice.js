import { createSlice } from "@reduxjs/toolkit";
import { getJobListings } from "../thunk/Jobs.thunk";

const initialState = {
    jobsList: null,
    jobsListLoading: false,
    jobsListError: false
};

const jobsSlice = createSlice({
    name: "JOB_SLICE",
    initialState,
    reducers:{
        
    },
    extraReducers: (builder) => {
        builder.addCase(getJobListings.fulfilled,(state, action)=>{
            
            state.jobsList = action.payload;
            state.jobsListLoading = false;
        })
        .addCase(getJobListings.pending,(state)=>{
            console.log("ACTION")
            state.jobsListLoading = true;
        })
        .addCase(getJobListings.rejected, (state, action)=>{
            state.jobsListError = "Wrong Credentials";
            state.jobsListLoading = false;
        });
    }
})


export default jobsSlice.reducer;





