export const USER_SIDE_BAR_ITEMS = [
    {
        title: "Code Editor",
        image: "",
        link: "/codeeditor"
    },
    {
        title: "Screening Test",
        image: "",
        link: "/screeningtest"
    },
    {
        title: "Admin",
        image: "",
        link: "/admin"
    },
    
]

export const CANDIDATE_SIDE_BAR_ITEMS = [

    {
        title: "Code Editor",
        image: "",
        link: "/codeeditor"
    },
    {
        title: "Screening Test",
        image: "",
        link: "/screeningtest"
    },
]

export const ADMIN_SIDE_BAR_ITEMS = [
    {
        title: "Code Editor",
        image: "",
        link: "/codeeditor"
    },
    {
        title: "Admin",
        image: "",
        link: "/admin"
    },
    {
        title: "JD Generator",
        image: "",
        link: "/jdgenerator"
    },

]


