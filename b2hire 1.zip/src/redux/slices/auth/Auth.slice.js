import { login } from "../../thunk/auth/Auth.thunk";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    userDetails: JSON.parse(localStorage.getItem('login')),
    userLoading: false,
    authError: null,
    authToken: null
};

const authSlice = createSlice({
    name: "AUTH_SLICE",
    initialState,
    reducers:{
        setAuthToken(state, action) {
            state.userDetails = action.payload
          },
          logout(state) {
            state.authToken = null;
          },
    },
    extraReducers: (builder) => {
        builder.addCase(login.fulfilled,(state, action)=>{
            state.userDetails = action.payload;
            state.userLoading = false;
        })
        .addCase(login.pending,(state)=>{
            state.userLoading = true;
        })
        .addCase(login.rejected, (state, action)=>{
            state.authError = "Wrong Credentials";
            state.userLoading = false;
        });
    }
})

export const { setAuthToken, logout } = authSlice.actions;
export default authSlice.reducer;