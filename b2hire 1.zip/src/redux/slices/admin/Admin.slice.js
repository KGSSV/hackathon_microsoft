import {
  fetchCandidateInfo,
  fetchCandidates,
  generateJD,
} from "../../thunk/admin/Admin.thunk";
import { login } from "../../thunk/auth/Auth.thunk";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  candidatesList: null,
  candidatesListLoading: false,
  candidatesListError: false,
  candidateInfo: null,
  candidateInfoLoading: false,
  generatedJd: null,
  generatedJdLoading: false,
};

const adminSlice = createSlice({
  name: "ADMIN_SLICE",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCandidates.fulfilled, (state, action) => {
        state.candidatesList = action.payload;
        state.candidatesListLoading = false;
      })
      .addCase(fetchCandidates.pending, (state) => {
        state.candidatesListLoading = true;
      })
      .addCase(fetchCandidates.rejected, (state, action) => {
        state.candidatesListError = true;
        state.candidatesListLoading = false;
      })
      .addCase(fetchCandidateInfo.fulfilled, (state, action) => {
        state.candidateInfo = action.payload;
        state.candidateInfoLoading = false;
      })
      .addCase(fetchCandidateInfo.pending, (state) => {
        state.candidateInfoLoading = true;
      })
      .addCase(generateJD.fulfilled, (state, action) => {
        state.generatedJd = action.payload;
        state.generatedJdLoading = false;
      })
      .addCase(generateJD.pending, (state) => {
        state.generatedJdLoading = true;
      });
  },
});

export default adminSlice.reducer;
