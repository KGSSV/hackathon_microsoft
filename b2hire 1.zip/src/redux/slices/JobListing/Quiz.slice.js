// quizSlice.js
import { createSlice } from '@reduxjs/toolkit';

const quizSlice = createSlice({
  name: 'quiz',
  initialState: [],
  reducers: {
    submitQuiz(state, action) {
      // Save the selected options to the state
      state.push(action.payload);
    },
  },
});

export const { submitQuiz } = quizSlice.actions;
export const selectQuiz = (state) => state.quiz;
export default quizSlice.reducer;
