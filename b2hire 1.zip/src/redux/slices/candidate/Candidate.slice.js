import { createSlice } from "@reduxjs/toolkit";
import { fetchScreeningQuestions } from "../../thunk/candidate/Candidate.thunk";

const initialState = {
    questionList: null,
    questionListLoading: false,
    questionListError: false,
    roomJoined: false,
    code: ""
   
};

const candidateSlice = createSlice({
    name: "Cnadidate_SLICE",
    initialState,
    reducers:{
        setCode(state, action){
            state.code = action.payload;
        },
        setRoomJoined(state, action){
            state.roomJoined = action.payload;
        }
    },
    extraReducers: (builder) => {
        builder.addCase(fetchScreeningQuestions.fulfilled,(state, action)=>{
            state.questionList = action.payload;
            state.questionListLoading = false;
        })
        .addCase(fetchScreeningQuestions.pending,(state)=>{
            state.questionListLoading = true;
        })
        .addCase(fetchScreeningQuestions.rejected, (state, action)=>{
            state.questionListError = true;
            state.questionListLoading = false;
        });
    }
})

export const {setCode, setRoomJoined} = candidateSlice.actions;
export default candidateSlice.reducer;