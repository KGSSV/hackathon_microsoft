import { configureStore } from "@reduxjs/toolkit";
import AuthReducer from "./slices/auth/Auth.slice";
import quizReducer from "./slices/JobListing/Quiz.slice"
import AdminReducer from "./slices/admin/Admin.slice";
import CandidateReducer from "./slices/candidate/Candidate.slice";

const store = configureStore({
    reducer: {
      auth: AuthReducer,
      quiz: quizReducer,
      admin: AdminReducer,
      candidate: CandidateReducer
    },
  });
  
  export default store;
  