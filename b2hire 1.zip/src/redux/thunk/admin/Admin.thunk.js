import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchCandidates = createAsyncThunk("admin/fetchCandidates", async (userDetail) => {
  try {
    const { data } = await axios.get(
      `${process.env.REACT_APP_BACKEND_BASE_URL}/adminfetch`,
    );
    return data;
  } catch (error) {
    throw new Error("Unable to fetch data");
  }
});


export const fetchCandidateInfo = createAsyncThunk("admin/fetchCandidateInfo", async ({email, jid}) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/getcandidateinfo`,
        {
            emailid: email,
            jid: jid
        }
      );
      return data;
    } catch (error) {
      throw new Error("Unable to fetch data");
    }
  });
  

  export const generateJD = createAsyncThunk("admin/generateJD", async (params) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/jdgen`,
        {
            prevconvo: "None",
            trajectory: params.trajectory,
            scope: params.scope,
            skills: params.skills,
            techstacks: params.techstacks === '' ? "None" : params.techstacks,
            yoe:params.yoe,
            additionalInfo: params.additionalInfo
        }
      );
      return data;
    } catch (error) {
      throw new Error("Unable to fetch data");
    }
  });
