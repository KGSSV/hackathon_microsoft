import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const login = createAsyncThunk("auth/login", async (userDetails) => {
  try {
    const { data } = await axios.post(
      `${process.env.REACT_APP_BACKEND_BASE_URL}/login`,
      {
        emailid: userDetails.username,
        password: userDetails.password,
      }
    );
    localStorage.setItem('login', JSON.stringify(data));
    return data;
  } catch (error) {
    throw new Error("Unable to fetch data");
  }
});
