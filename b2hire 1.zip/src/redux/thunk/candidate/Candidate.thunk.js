import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";



export const fetchScreeningQuestions = createAsyncThunk("candidate/fetchScreeningQuestions", async ({emailid, jid}) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/getmaintest`,
        {
            emailid: emailid,
            jid: jid
        }
      );
      return data;
    } catch (error) {
      throw new Error("Unable to fetch data");
    }
  });

  export const generateScreeningQuestions = createAsyncThunk("candidate/generateScreeningQuestions", async ({email, jid}) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/processstart`,
        {
            emailid: email,
            cstatus:"Exam Gen In Processs",
            jid: jid
        }
      );
      return data;
    } catch (error) {
      throw new Error("Unable to fetch data");
    }
  });


  export const submitEnd = createAsyncThunk("candidate/submitEnd", async ({email, responses, jid}) => {
    try {
      const { data } = await axios.post(
        `${process.env.REACT_APP_BACKEND_BASE_URL}/submitend`,
        {
            emailid: email,
            qanswers: responses,
            jid: jid
        }
      );
      return data;
    } catch (error) {
      throw new Error("Unable to fetch data");
    }
  });

  


  
  



