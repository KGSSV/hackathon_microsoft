import React, { useState, useEffect } from 'react';
import { Container, TextField, Button, Grid, Box } from '@mui/material';
import TextareaAutosize from '@mui/material/TextareaAutosize';
import { styled } from '@mui/system';
import { createTheme } from '@mui/material/styles';
import { useDispatch, useSelector } from 'react-redux';
import { generateJD } from '../redux/thunk/admin/Admin.thunk';
import Loader from '../components/Loader';

const theme = createTheme();

const StyledTextarea = styled(TextareaAutosize)(({ theme }) => ({
  width: '100%',
  padding: '16.5px 14px',
  fontSize: '1rem',
  borderColor: 'black',
  borderRadius: '4px',
  borderWidth: '1px',
  borderStyle: 'solid',
  boxSizing: 'border-box',
  outline: 'none',
  '&:focus': {
    borderColor: 'blue',
  },
}));

const JDGenerator = () => {
  const [trajectory, setTrajectory] = useState('');
  const [scope, setScope] = useState('');
  const [skills, setSkills] = useState('');
  const [techStack, setTechStack] = useState('');
  const [experience, setExperience] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);
  const [generatedJDs, setGeneratedJDs] = useState('');

  const { generatedJdLoading, generatedJd } = useSelector((state) => state.admin);
  const dispatch = useDispatch();

  useEffect(() => {
    const checkRequiredFields = () => {
      if (
        trajectory.trim() !== '' &&
        scope.trim() !== '' &&
        skills.trim() !== '' &&
        techStack.trim() !== '' &&
        experience.trim() !== ''
      ) {
        setIsButtonDisabled(false);
      } else {
        setIsButtonDisabled(true);
      }
    };

    checkRequiredFields();
  }, [trajectory, scope, skills, techStack, experience]);

  const handleGenerateJD = () => {
    const jobDescription = {
      trajectory: trajectory,
      scope: scope,
      skills: skills,
      techstacks: techStack,
      yoe: experience,
      additionalInfo: additionalInfo,
    };
   dispatch(generateJD(jobDescription));
   
  };

  return (
    <Container maxWidth="xl" style={{ marginTop: '20px' }}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Trajectory"
            variant="outlined"
            required
            value={trajectory}
            onChange={(e) => setTrajectory(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Scope"
            variant="outlined"
            required
            value={scope}
            onChange={(e) => setScope(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Skills"
            variant="outlined"
            required
            value={skills}
            onChange={(e) => setSkills(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Tech Stack"
            variant="outlined"
            required
            value={techStack}
            onChange={(e) => setTechStack(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Year Of Experience Required"
            type="number"
            variant="outlined"
            required
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Additional Info"
            variant="outlined"
            multiline
            rows={4}
            value={additionalInfo}
            onChange={(e) => setAdditionalInfo(e.target.value)}
          />
        </Grid>
        <Grid item xs={12}>
          <Button
            fullWidth
            variant="contained"
            color="primary"
            onClick={handleGenerateJD}
            disabled={isButtonDisabled}
          >
            Generate JD
          </Button>
        </Grid>
        
         <Grid item xs={12}>
         {generatedJdLoading && <Loader/>}
          <StyledTextarea
            fullWidth
            label="Generated Job Description"
            variant="outlined"
            multiline
            minRows={6}
            value={generatedJd}
            onChange={(e) => setGeneratedJDs(e.target.value)}
            
          />
        </Grid>
      </Grid>
    </Container>
  );
};

export default JDGenerator;
