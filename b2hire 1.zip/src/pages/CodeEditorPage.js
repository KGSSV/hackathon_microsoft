import React from "react";
import CodeEditorHome from "../codeeditor/CodeEditorHome";
import { ChakraProvider } from "@chakra-ui/react";
import theme from "../codeeditor/theme";

export default function CodeEditorPage() {
  return (
    <ChakraProvider theme={theme}>
      <CodeEditorHome />
    </ChakraProvider>
  );
}
