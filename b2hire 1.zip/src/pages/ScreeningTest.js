import React, { useState, useEffect } from 'react';
import QuizModal from '../components/QuizModal';
import { Button } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { fetchScreeningQuestions } from '../redux/thunk/candidate/Candidate.thunk';
import Loader from '../components/Loader';


const ScreeningTest = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const dispatch = useDispatch();
  const { userDetails } = useSelector((state) => state.auth);
  const { questionList, questionListLoading } = useSelector((state) => state.candidate);
  

  const handleOpenModal = () => {
    setIsModalOpen(true);
    const emailid = userDetails?.emailid;
    const jid = userDetails?.JID;
    dispatch(fetchScreeningQuestions({emailid, jid}))
    openFullScreen();
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    closeFullScreen();
  };

  const openFullScreen = () => {
    const elem = document.documentElement;
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) {
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
      elem.msRequestFullscreen();
    }
  };

  const closeFullScreen = () => {
    if (document.fullscreenElement) {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
    }
  };

  return (
    <>
      <h1>Read the below Guidelines before starting the test</h1>
      <h3>Guidelines:</h3>
      <ol>
        <li><strong>Exiting full-screen mode will end the test.</strong></li>
        <li><strong>If you accidentally exit full screen, click the "Return To Fullscreen" button on the warning message to return to full screen.</strong></li>
        <li><strong>Clicking "Exit Test" will also end the test.</strong></li>
        <li><strong>The timer will continue running even if you exit full screen.</strong></li>
        <li><strong>Once you have answered all the questions, click the "Submit" button.</strong></li>
        <li><strong>If the time runs out, also click "Submit" to save your responses to the attempted questions.</strong></li>
      </ol>
      <Button variant="contained" color="primary" onClick={handleOpenModal}>
        Start Test
      </Button>
      {isModalOpen && (
        <>
          {questionListLoading ? (
            <Loader/>
          ) : (
            questionList.length > 0 && (
              <QuizModal
                questions={questionList}
                onClose={handleCloseModal}
              />
            )
          )}
        </>
      )}
    </>
  );
};

export default ScreeningTest;
