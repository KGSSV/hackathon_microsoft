import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { Paper } from "@mui/material";
import { IconButton, InputAdornment } from "@mui/material";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import VisibilityIcon from "@mui/icons-material/Visibility";
import { login } from "../redux/thunk/auth/Auth.thunk";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";



function Copyright(props) {
  return (
    <Typography
      component="h1"
      variant="body2"
      color="text.secondary"
      align="center"
      {...props}
    >
      {"Powered by "}
      <Link color="inherit" href="https://www.brillio.com/">
        Brillio
      </Link>{" "}
      {new Date().getFullYear()}
      {" © "}
    </Typography>
  );
}

// TODO remove, this demo shouldn't need to reset the theme.

const defaultTheme = createTheme();

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState('');
  const { userDetails } = useSelector((state) => state.auth);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };
  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };


  const handlePasswordOnblur = (event) => {
    const newErrors = {};

    const password = event.target.value;
    if (password.length < 8) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        password: "Password must be at least 8 characters long",
      }));
    } else {
      setErrors((prevErrors) => ({
        ...prevErrors,
        password: "",
      }));
    }
  };

  const handleEmailInput = (event) => {
    setEmail(event.target.value);
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = data.get("email");
    const password = data.get("password");

    if (errors.email === "" && errors.password === "") {
      const userCreds = {
        username: email,
        password: password,
      };
      dispatch(login(userCreds))
    }
  };

  
  const storedData = localStorage.getItem("user");

  useEffect(() => {
    let login = localStorage.getItem("login");
    console.log("USEEFFECT",userDetails)
    if(userDetails){
        navigate('/')
    }
}, [userDetails])

  return (
    <ThemeProvider theme={defaultTheme}>
      <div>
        <hr style={{ marginLeft: "20px", marginRight: "20px" }} />
      </div>
      <Container component="main">
        <CssBaseline />
        <Grid container spacing={2}>
          <Grid item md={4}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "400px",
                marginTop: "30px",
                marginLeft: 20,
              }}
            >
              <img
                src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp"
                className="img-fluid"
                alt="Sample image"
                style={{ maxWidth: "150%" }}
              />
            </Box>
          </Grid>
          <Grid item md={6} sx={{ marginLeft: "16%" }}>
            <Box
              component={Paper}
              elevation={3}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "400px",
                padding: "10px",
                boxShadow: "0px 0px 8px rgba(0, 0, 0, 0.4)",
                marginTop: "30px",
                width: 400,
                marginLeft: 20,
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  width: "80%",
                }}
              >
                <Typography
                  component="h1"
                  variant="h5"
                  sx={{ mb: 3 }}
                  style={{ fontWeight: "bold" }}
                >
                  Sign in
                </Typography>
                {/* {authError && (
                  <Typography
                    component="p"
                    variant="body1"
                    color="error"
                    sx={{ mb: 2 }}
                  >
                    Wrong Credentials
                  </Typography>
                )} */}
                <Box
                  component="form"
                  onSubmit={handleSubmit}
                  noValidate
                  sx={{ mt: 1 }}
                >
                  {errors.email && (
                    <Typography
                      component="p"
                      variant="body1"
                      color="error"
                      sx={{ mb: 2 }}
                    >
                      {errors.email}
                    </Typography>
                  )}
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="email"
                    onBlur={handleEmailInput}
                    onChange={handleEmailInput}
                    label="User Name"
                    name="email"
                    autoComplete="email"
                    autoFocus
                  />
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    name="password"
                    label="Password"
                    type={showPassword ? "text" : "password"}
                    id="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={handlePasswordChange}
                    onBlur={handlePasswordOnblur}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            onClick={handleTogglePasswordVisibility}
                            edge="end"
                          >
                            {showPassword ? (
                              <VisibilityIcon />
                            ) : (
                              <VisibilityOffIcon />
                            )}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />
                   {errors.password && (
                    <Typography
                      component="p"
                      variant="body1"
                      color="error"
                      sx={{ mb: 2 }}
                    >
                      {errors.password}
                    </Typography>
                  )}
                  {/* {userLoading && (
                    <div style={{ paddingLeft: "50%" }}>
                      <Loader />
                    </div>
                  )} */}
                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2 }}
                    disabled={!password || !email}
                  >
                    Sign In
                  </Button>
                </Box>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </ThemeProvider>
  );
}
