
import React from 'react'
import Table from '../components/Table';
import { useSelector } from 'react-redux';

import Loader from '../components/Loader';


const columns = [
  { field: 'id', headerName: 'Email', width: 250 },
  {
    field: 'name',
    headerName: 'Name',
    width: 250,
  },
  {
    field: 'JID',
    headerName: 'Job ID',
    width: 100,
  },
  {
    field: 'cstatus',
    headerName: 'Status',
    width: 250,
    renderCell: (params) => {
      let color = '';
      switch (params.value) {
        case 'REJECTED':
          color = 'red';
          break;
        case 'INTERVIEW INITIATED':
          color = '#6f42c1';
          break;
        case 'TEST INITIATED':
          color = '#ffc107';
          break;
        case 'TEST ATTEMPTED':
          color = '#007bff';
          break;
        case 'INITIAL OK':
          color = '#28a745';
          break;
        default:
          color = '';
          break;
      }

      return (
        <span style={{ color, fontWeight: "bold" }}>
          {params.value}
        </span>
      );
    },
  },
 
];




export default function Admin() {

  const { candidatesList, candidatesListLoading } = useSelector((state) => state.admin);

  // useEffect(() => {
  //   dispatch(fetchCandidates());
  // }, [])
  
  return (
    <div>
      {candidatesListLoading && <Loader/>}
      {!candidatesListLoading && candidatesList &&
        <Table columns={columns} rows={candidatesList}/>
      }
      
    </div>
  )
}
