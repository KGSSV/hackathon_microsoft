import React from 'react';
import { Route, Routes } from "react-router-dom";
import ScreeningTest from '../pages/ScreeningTest';
import Login from '../pages/Login';
import ProtectedRoute from './ProtectedRoute';
import SideBar from '../components/SideBar';
import Home from '../pages/Home';
import CodeEditorPage from '../pages/CodeEditorPage';
import Admin from '../pages/Admin';
import JDGenerator from '../pages/JDGenerator';

export default function AppRoutes() {
  return (
    <Routes>
      
      <Route path="/login" element={<Login/>}/>
      <Route path="/" element={<ProtectedRoute Component={Home}/>}/>
        <Route path="/codeeditor" element={<ProtectedRoute Component={CodeEditorPage}/>}/>
        <Route path="/screeningtest" element={<ProtectedRoute Component={ScreeningTest}/>}/>
        <Route path="/jdgenerator" element={<ProtectedRoute Component={JDGenerator}/>}/>
        <Route path="/admin" element={<ProtectedRoute Component={Admin}/>}/>
    </Routes>
  )
}
