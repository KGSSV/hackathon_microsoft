import React, {useEffect} from 'react'
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import Login from '../pages/Login';


export default function ProtectedRoute(props) {
    const { Component } = props;
    const navigate = useNavigate();
    const { userDetails } = useSelector((state) => state.auth);
    let login = localStorage.getItem("login");
   
    
  return (
    <div>
        {userDetails ? <Component/> : <Login/>}
    </div>
  )
}
