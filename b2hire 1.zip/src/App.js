import './App.css';
import { BrowserRouter as Router } from "react-router-dom";
import AppRoutes from './navigation/AppRoutes';
import ProtectedRoute from './navigation/ProtectedRoute';
import Login from './pages/Login';
import { useDispatch, useSelector } from 'react-redux';
import NavBar from './components/SideBar';
import { fetchCandidates } from './redux/thunk/admin/Admin.thunk';
import { useEffect } from 'react';



function App() {
  const dispatch = useDispatch();
  let isAuthenticated = localStorage.getItem("login");
  const { userDetails } = useSelector((state) => state.auth);
  useEffect(() => {
    if(userDetails?.usertype === 'admin') dispatch(fetchCandidates());
  }, [userDetails])
  
  
  return (
    <Router>
      <NavBar/>
    </Router>
    
  );
}

export default App;
