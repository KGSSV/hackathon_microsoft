import { useToast } from '@chakra-ui/react'
import { useEffect } from 'react'

export default function Toast({ msg, isOpen }) {
  const toast = useToast()

  useEffect(() => {
    if (isOpen) {
      toast({
        title: '',
        description: msg,
        status: 'success',
        duration: 9000,
        isClosable: true,
      })
    }
  }, [isOpen, toast, msg])

  return null
}
