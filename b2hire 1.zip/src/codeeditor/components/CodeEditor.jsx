import React, { useRef, useState, useEffect } from "react";
import { Box, HStack } from "@chakra-ui/react";
import { Editor } from "@monaco-editor/react";
import LanguageSelector from "./LanguageSelector";
import { CODE_SNIPPETS } from "../constants";
import Output from "./Output";
import CodeReview from "./CodeReview";
import { useDispatch, useSelector } from "react-redux";

import io from "socket.io-client";
import {
  setCode,
  setRoomJoined,
} from "../../redux/slices/candidate/Candidate.slice";
import JoinRoom from "../../components/JoinRoom";
import Home from "../../pages/Home";
import { Input, Stack,Button, ButtonGroup } from "@chakra-ui/react";
import Toast from "./Toast";

const socket = io("http://4.240.75.244:8095");

const CodeEditor = () => {
  const editorRef = useRef();
  const containerRef = useRef();
  const [value, setValue] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [username, setUsername] = useState("");
  const [room, setRoom] = useState("");
  const [text, setText] = useState("");
  const [messages, setMessages] = useState([]);
  const [toastIsOpen, settoastIsOpen] = useState(false)

  const dispatch = useDispatch();

  const { code, roomJoined } = useSelector((state) => state.candidate);
  const { userDetails } = useSelector((state) => state.auth);

  useEffect(() => {
    socket.on("text_change", (data) => {
      //console.log("DATA", data)
      dispatch(setCode(data.text));
      setText(data.text);
      setLanguage(data.language)
    });

    socket.on("message", (message) => {
      settoastIsOpen(true)
      setMessages((prevMessages) => [...prevMessages, message]);
    });

    socket.on("code_change", (data) => {
      console.log("LAN", data)
      setLanguage(data.language);
      setValue(CODE_SNIPPETS[data.language]);
    dispatch(setCode(CODE_SNIPPETS[data.language]))
    });

    return () => {
      socket.off("text_change");
      socket.off("message");
      socket.off("code_change");
    };
  }, []);

  const joinRoom = () => {
    if (username && room) {
      socket.emit("join", { username, room });
      dispatch(setRoomJoined(true));
    }
  };

  const leaveRoom = () => {
    socket.emit("leave", { username, room });
    dispatch(setRoomJoined(false));
  };

  const handleTextChange = (event) => {
   
    dispatch(setCode(event));
    setText(event)
    socket.emit("text_change", { room, text: event });
  };
  
  const onSelect = (language) => {
    console.log("Handle lang", language)
    setLanguage(language);
    setValue(CODE_SNIPPETS[language]);
    dispatch(setCode(CODE_SNIPPETS[language]))
    socket.emit("code_change", { room, language: language });
  };
  const onMount = (editor) => {
    editorRef.current = editor;
    editor.focus();
  };


  useEffect(() => {
    const handleResize = () => {
      if (editorRef.current) {
        editorRef.current.layout();
      }
    };

    const debounceResize = () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(handleResize, 100);
    };

    let resizeTimeout;
    const resizeObserver = new ResizeObserver(debounceResize);

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        resizeObserver.unobserve(containerRef.current);
      }
      clearTimeout(resizeTimeout);
    };
  }, []);

  

  return (
    <>
   {messages.map((msg, index) => {
        return <Toast key={index} isOpen={true} msg={msg} />
      })}
      {!roomJoined ? (
          <Stack spacing={3} w="50%">
            <Input
            color="teal"
              placeholder="Username"
              _placeholder={{ opacity: 1, color: "gray.500" }}
              onChange={(e) => setUsername(e.target.value)}
            />
            <Input
              color="teal"
              onChange={(e) => setRoom(e.target.value)}
              placeholder="Room"
              _placeholder={{ opacity: 1, color: "gray.500" }}
            />
            <Button onClick={joinRoom} colorScheme='blue'>Join Room</Button>
          </Stack>
      ) : (
        <Box ref={containerRef} w="100%" h="100vh">
          
          <Button onClick={leaveRoom} colorScheme='blue'>Leave Room</Button>
          <HStack spacing={4} h="100%">
            <Box w="75%" h="100%">
              <LanguageSelector language={language} onSelect={onSelect} />
              <Editor
                options={{
                  minimap: {
                    enabled: false,
                  },
                }}
                height="calc(100% - 40px)" // Adjusting height to account for the LanguageSelector height
                width="100%"
                theme="vs-dark"
                language={language}
                defaultValue={CODE_SNIPPETS[language]}
                onMount={onMount}
                value={code}
                onChange={handleTextChange}
              />
            </Box>
            <Output editorRef={editorRef} language={language} />
            {userDetails?.usertype === "admin" ?
            (<CodeReview />):(<div></div>)
          }
          </HStack>
        </Box>
      )}
    </>
  );
};

export default CodeEditor;
