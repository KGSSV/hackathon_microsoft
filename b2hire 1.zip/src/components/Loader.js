import * as React from 'react';
import Box from '@mui/material/Box';



// From https://github.com/mui/material-ui/issues/9496#issuecomment-959408221

export default function Loader() {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
        }}
      >
        <iframe
        title="Lottie Animation"
        src="https://lottie.host/embed/c46b42be-e594-4433-b6c3-f7512049f19e/GJo9gMUPSo.json"
        frameBorder="0"
        allowFullScreen
      ></iframe>
      </Box>
    );
  }
  