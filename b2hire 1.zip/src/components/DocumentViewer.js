import DocViewer, { DocViewerRenderers } from "@cyntler/react-doc-viewer";

export default function DocumentViewer({ url }) {
  console.log("URL", url);
  const docs = [
    { uri: url }, // Local File
  ];

  return (
    <div style={{ height: '80vh', overflow: 'auto' }}>
      <DocViewer style={{ width: '100%', height: '100%' }} documents={docs} pluginRenderers={DocViewerRenderers} />
    </div>
  );
}
