import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import AlertDialog from '../components/AlertDialog';
import { submitQuiz } from '../redux/slices/JobListing/Quiz.slice';
import { submitEnd } from '../redux/thunk/candidate/Candidate.thunk';

const useStyles = makeStyles((theme) => ({
  paper: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(2),
    overflowY: 'auto', // Make content scrollable
    maxHeight: '70vh', // Set max height to 70% of viewport height
  },
  question: {
    marginBottom: theme.spacing(2),
    fontWeight: 'bold', // Make questions bold
  },
  options: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: theme.spacing(1),
    marginTop: theme.spacing(1),
  },
  option: {
    padding: theme.spacing(1),
    border: '1px solid #ddd',
    borderRadius: theme.shape.borderRadius,
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    '&:hover': {
      backgroundColor: '#f5f5f5',
    },
  },
  selectedOption: {
    backgroundColor: '#d4edda', // Green color for selected option
    borderColor: '#c3e6cb',
  },
  divider: {
    margin: theme.spacing(2, 0),
    borderTop: '1px solid #ddd',
  },
  timer: {
    position: 'absolute',
    top: theme.spacing(2),
    right: theme.spacing(2),
    fontWeight: 'bold',
    fontSize: '1.5rem',
    color: theme.palette.primary.main,
    transition: 'color 0.3s',
  },
  redTimer: {
    color: 'red',
  },
  '@keyframes fadeIn': {
    '0%': {
      opacity: 0,
    },
    '100%': {
      opacity: 1,
    },
  },
  timerAnimation: {
    animation: '$fadeIn 0.5s linear',
  },
}));

const QuizModal = ({ questions, onClose }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [timer, setTimer] = useState(20); // 60 seconds timer
  const [selectedOptions, setSelectedOptions] = useState({});
  const [tabSwitchCount, setTabSwitchCount] = useState(0);
  const [openDialog, setOpenDialog] = useState(false);
  const [timerClass, setTimerClass] = useState(classes.timer);
  const { userDetails } = useSelector((state) => state.auth);
  

  useEffect(() => {
    if (timer <= 10) {
      setTimerClass(`${classes.timer} ${classes.redTimer}`);
    } else {
      setTimerClass(classes.timer);
    }
  }, [timer]);

  const handleVisibilityChange = () => {
    if (document.hidden) {
      setTabSwitchCount((count) => count + 1);
      setOpenDialog(true);
    }
  };
  useEffect(() => {
    const timerInterval = setInterval(() => {
      setTimer((prevTimer) => (prevTimer > 0 ? prevTimer - 1 : 0));
    }, 1000);

    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('fullscreenchange', handleFullscreenChange);

    return () => {
      clearInterval(timerInterval);
      
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);



  const handleKeyDown = (event) => {
    if (event.key === 'Escape' && document.fullscreenElement) {
      event.preventDefault();
      setOpenDialog(true);
    }
  };

  const handleFullscreenChange = () => {
    if (!document.fullscreenElement && document.visibilityState === 'visible') {
      setOpenDialog(true);
    }
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    onClose();
  };

  const handleAgreeDialog = () => {
    openFullScreen();
    setOpenDialog(false);
  };

  const openFullScreen = () => {
    const elem = document.documentElement;
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) {
      elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
      elem.msRequestFullscreen();
    }
  };

  const handleOptionChange = (questionId, optionId) => {
    setSelectedOptions((prevOptions) => {
      const updatedOptions = { ...prevOptions };
      if (updatedOptions[questionId]?.includes(optionId)) {
        // If option is already selected, remove it
        updatedOptions[questionId] = updatedOptions[questionId].filter((id) => id !== optionId);
      } else {
        // If option is not selected, add it
        updatedOptions[questionId] = [...(updatedOptions[questionId] || []), optionId];
      }
      return updatedOptions;
    });
  };
  

  const handleSubmit = () => {
    
    const responses = questions.map((question, index) => {
      //console.log(selectedOptions[question.id]?.[0] ?? null)
      const selectedOption = question.options.find(option => option.id === selectedOptions[question.id]?.[0]);
      console.log("opts",selectedOption)
      return {
          question: question.question,
          answer: selectedOption ? selectedOption.text : null,
          isCorrect: selectedOption ? selectedOption.isCorrect : null
      };
  });
    const quizResponse = {
      answers: responses,
      tabSwitchCount: tabSwitchCount,
    };
    console.log("RESPONSE", responses)
    dispatch(submitQuiz(quizResponse));
    const email = userDetails?.emailid;
    const jid =  userDetails?.JID;
    dispatch(submitEnd({email, responses, jid}))
    onClose();
  };

  return (
    <>
      <AlertDialog open={openDialog} onClose={handleCloseDialog} onAgree={handleAgreeDialog} />
      <Dialog open={true} onClose={() => {}} fullScreen>
        <DialogTitle>
          <Typography variant='h3' align="center">Brillio Hiring Test</Typography>
          <Typography variant='h6' className={timerClass} align="right">
            Time remaining: {timer} seconds
          </Typography>
        </DialogTitle>
        <DialogContent className={classes.paper}>
          {timer <= 0 ? (
            <Typography variant="h6" align="center">Time's up!</Typography>
          ) : (
            <>
              {questions.map((question, index) => (
                <div key={question.id} className={classes.question}>
                  <Typography variant="body1">
                    <Box component="span" fontWeight="fontWeightBold">{index + 1}.</Box> {question.question}
                  </Typography>
                  <div className={classes.options}>
                    {question.options.map((option) => (
                      <div
                        key={option.id}
                        className={`${classes.option} ${selectedOptions[question.id]?.includes(option.id) ? classes.selectedOption : ''}`}
                        onClick={() => handleOptionChange(question.id, option.id)}
                      >
                        {option.text}
                      </div>
                    ))}
                  </div>
                  {index !== questions.length - 1 && <div className={classes.divider} />}
                </div>
              ))}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSubmit} color="primary" >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default QuizModal;

