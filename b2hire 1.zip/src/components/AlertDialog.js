import React, {useEffect} from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';

const AlertDialog = ({ open, onClose, onAgree }) => {
  const handleVisibilityChange = () => {
    if (document.hidden) {
      onClose();
    }
  };
  useEffect(() => {
   

    document.addEventListener('visibilitychange', handleVisibilityChange);
 

    return () => {
     
      
      document.removeEventListener('visibilitychange', handleVisibilityChange);
  
    };
  }, []);
  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Alert</DialogTitle>
      <DialogContent>
        <p>You have exited the full-screen mode. Please stay in full-screen to complete the quiz.</p>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Exit Test</Button>
        <Button onClick={onAgree} autoFocus>
          Return To Fullscreen
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AlertDialog;
