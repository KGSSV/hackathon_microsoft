import React, {useEffect, useState} from 'react';
import Box from '@mui/material/Box';
import { DataGrid } from '@mui/x-data-grid';
import { Button } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCandidateInfo } from '../redux/thunk/admin/Admin.thunk';
import DocumentViewerModal from './DocumentViewerModal';
import {  generateScreeningQuestions } from '../redux/thunk/candidate/Candidate.thunk';


export default function Table({ columns, rows }) {

  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const { candidateInfo } = useSelector((state) => state.admin);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleTestButtonClick = (email, jid) => {
    dispatch(generateScreeningQuestions({email,jid}));
    console.log("Initiate Test for", email);
  };

  const handleInterviewButtonClick = (email) => {
    console.log("Initiate Interview for", email);
  };


  const handleViewResumeClick = (email, jid) => {
    dispatch(fetchCandidateInfo({email, jid}));
    handleClickOpen();
  }

  useEffect(() => {
  
  }, [candidateInfo])
  

  const columnsWithButtons = [
    ...columns,
    {
      field: 'actions',
      headerName: 'Actions',
      width: 300,
      renderCell: (params) => (
        <>
        <Button
              variant="contained"
              color="primary"
              size="small"
              onClick={() => handleViewResumeClick(params.row.id, params.row.JID)}
              style={{ marginRight: '10px' }}
            >
              View Resume
            </Button>
          {params.row.cstatus === 'INITIAL OK' && (
            <Button
              variant="contained"
              color="primary"
              size="small"
              onClick={() => handleTestButtonClick(params.row.id, params.row.JID)}
              style={{ marginRight: '10px' }}
            >
              Initiate Test
            </Button>
          )}
          {params.row.cstatus === 'TEST COMPLETED' && (
            <Button
              variant="contained"
              color="success"
              size="small"
              onClick={() => handleInterviewButtonClick(params.row.id)}
            >
              Initiate Interview
            </Button>
          )}
        </>
      ),
    },
  ];

  return (
    <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        disableSelectionOnClick
        rows={rows}
        columns={columnsWithButtons}
        pageSize={5}
      />
     <DocumentViewerModal open={open} handleClose={handleClose} />
    </Box>
  );
}
