import React, {useState} from 'react'
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
export default function JoinRoom() {

    const [username, setUsername] = useState("");
    const [room, setRoom] = useState("");
  return (
    <div>
         
          <TextField
            label="Room"
            value={room}
            onChange={(e) => setRoom(e.target.value)}
            fullWidth
          />
          <Button
            variant="contained"
            color="primary"
            fullWidth
          >
            Join Room
          </Button>
        </div>
  )
}
