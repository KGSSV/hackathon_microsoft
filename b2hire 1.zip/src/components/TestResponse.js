import React from 'react';
import { Typography, Grid, Box, Paper } from '@mui/material';

const TestResponse = ({ response }) => {
  return (
    <Grid container spacing={2}>
      {response.map((item, index) => (
        <Grid item xs={12} key={index}>
          <Paper elevation={3} sx={{ padding: 2 }}>
            <Typography variant="h7" gutterBottom>
              {index + 1}. {item.question}
            </Typography>
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Typography variant="body1" color="textSecondary">
                Answer: {item.answer ? item.answer : "Not answered"}
              </Typography>
              <Typography variant="body1" color={item.isCorrect === null ? "textSecondary" : item.isCorrect ? "green" : "red"}>
                {item.isCorrect === null ? "" : item.isCorrect ? "Correct" : "Incorrect"}
              </Typography>
            </Box>
          </Paper>
        </Grid>
      ))}
    </Grid>
  );
};

export default TestResponse;
