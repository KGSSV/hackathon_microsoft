import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import DocumentViewer from './DocumentViewer';
import { Typography } from '@mui/material';
import { useSelector } from 'react-redux';
import TestResponse from './TestResponse';


export default function NavTab() {
  const [value, setValue] = React.useState('Resume');
  const { candidateInfo } = useSelector((state) => state.admin);

  const handleChange = ( newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="Resume" value="Resume" />
            <Tab label="Job Description" value="Job Description" />
            {candidateInfo?.testResponses && <Tab label="Test Response" value="Test Response" />}
            
          </TabList>
        </Box>
        <TabPanel value="Resume">
  <div style={{ height: '80vh', overflow: 'auto' }}>
    <DocumentViewer url={candidateInfo.resumelink} />
  </div>
</TabPanel>

        <TabPanel value="Job Description">
            <div>
            <Typography variant="h5" gutterBottom>
                Job Description
              </Typography>
              <Typography variant="body1" paragraph>
                {candidateInfo?.jobDescContent}
              </Typography>
            </div>
        </TabPanel>
        {candidateInfo?.testResponses &&
        <TabPanel value="Test Response">
            <div>
            <Typography variant="h5" gutterBottom>
                Test Response
              </Typography>
              <TestResponse response={candidateInfo?.testResponses}/>
            </div>
        </TabPanel>
}
      </TabContext>
    </Box>
  );
}
